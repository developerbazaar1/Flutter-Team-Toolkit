# newtest_app

A new Flutter project.

## Getting Started

This project is a starting point for a Bottom Navigation Bar

dependencies
get: ^4.6.6
flutter_svg: ^2.0.17


